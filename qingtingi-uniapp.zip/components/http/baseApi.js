const BaseApi = 'https://stqingtingapi.youyacao.com/api/v1'

export {
	BaseApi
}
