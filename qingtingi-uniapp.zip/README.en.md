
# 蜻蜓I即时通讯v1.0.4系统完全开源-2025年1月2日优雅草科技蜻蜓i即时通讯系统开源-本系统对接goeasy的IMsdk-对应后端系统蜻蜓Q系统旗舰版也已经开源-优雅草krito|undefined


# 产品背景说明

蜻蜓I系统是采用蜻蜓Q旗舰版系统衍生开发的一个分支系统，此产品专注于即时通讯，因此仅有即时通讯聊天的功能无其他多余功能，2022年8月15日发布v1.0，将会不断升级打造一款简洁大气稳定的即时通讯聊天软件。 介绍 蜻蜓I系统包含朋友聊天，添加好友，删除好友，群聊，加入群聊，管理群聊等即时通讯功能，本产品为单一即时通讯而生并无其他功能，支持短信注册登录，蜻蜓I系统是2022年优雅草科技的商业产品-目前完整开源，本产品贡献最多成员为优雅草kirto，优雅草undefined两位兄弟。

# 更新日志

无

# 截图

![](https://doc.youyacao.com/server/index.php?s=/api/attachment/visitFile&sign=25e7e44423b384b49caf29d92bd95481)


![](https://doc.youyacao.com/server/index.php?s=/api/attachment/visitFile&sign=94799d0ce9d88824d09d1353f7864a5d)


![](https://doc.youyacao.com/server/index.php?s=/api/attachment/visitFile&sign=d2d75c3009d76cd830bd3ee15e9959bd)

![](https://doc.youyacao.com/server/index.php?s=/api/attachment/visitFile&sign=cca782ff3f31062a80c0f36e9c3021eb)

![](https://doc.youyacao.com/server/index.php?s=/api/attachment/visitFile&sign=a8da481fc7df0fd28fd2739039cf27ed)

![](https://doc.youyacao.com/server/index.php?s=/api/attachment/visitFile&sign=d3bc3278208a67932923b80437a0ecc6)

![](https://doc.youyacao.com/server/index.php?s=/api/attachment/visitFile&sign=0951e9d2eae6e1850ebca8deedb31553)
# 相关仓库地址

## 前端客户端地址

https://gitee.com/youyacao/qingtingi-uniapp

## 服务端地址

https://gitee.com/youyacao/st-qingting-api
## 后台管理地址
https://gitee.com/youyacao/st-qingting-admin


# 相关文档


# 更新日志
## 本次更新前端相关文件

无



##  本次更新服务端相关文件
无

##  本次更新后台管理相关文件
无


##  本次数据库结构改动

无

# 其他内容

## 互动交流QQ群

QQ群929353806

## 优雅草科技官网

www.youyacao.com

## 优雅草科技联系方式

QQ 422108995
WX 13708021643

更多联系方式：

https://doc2.youyacao.com/web/#/22/1024